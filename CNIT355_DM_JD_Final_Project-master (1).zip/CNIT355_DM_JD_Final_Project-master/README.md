# CNIT355_DM_JD_Final_Project
Talent management/booking app for CNIT355
Developers: Dylan Mumaw, Jeremy Diederich
Final Project for CNIT355
App can be used by entertainers and their management to view pay records, bookings, new talent, and venues. 
Venues will be able to book and view entertainers.
